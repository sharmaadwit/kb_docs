source_url: https://console-docs.gupshup.io/docs/conne

<!-- kb-golden:v10 -->
# Connecting FB Ad Account to Gupshup Ads Management

**Module**: Ctx

## Definition
Onboarding pre-requisites:

## Procedure
### Exact UI path
Gupshup Console → CTX → Connecting FB Ad Account to Gupshup Ads Management

### Prerequisites
- Access to **Gupshup Console → CTX → Connecting FB Ad Account to Gupshup Ads Management** in Gupshup Console.

### Fields to configure
- No explicit fields were identified in the source; use the UI controls shown on this page.

### Steps
1. Open Gupshup Console.
2. Go to Click to Chat Ads -> Ads Management
3. Click on "Connect Facebook Ad Account".
4. Click on "Confirm" and keep clicking on "Next" till the Gupshup console screen appears again.
5. Click on "Continue" and the onboarding is complete.
6. Click **Save** (or **Save & Deploy**) to apply changes.

### Validation / where to check
- Click on "Confirm" and keep clicking on "Next" till the Gupshup console screen appears again

### Troubleshooting
- If something does not work as expected, re-check the exact UI path, required fields, and any save/deploy step.

### Save / publish / deploy behavior
- Click **Save** (or **Save & Deploy**) to apply changes.

### Setup path
- Go to Click to Chat Ads -> Ads Management

## Options / variants
- No explicit UI variants/toggles were identified in the source for this page.

## Field mapping / schemas
- No explicit payload/schema details were identified in the source for this page.

## Field/payload examples
- No explicit payload examples were identified in the source.

## Cross-module workflow docs
- CTX campaign → Bot Studio journey → Goal measurement

## Module disambiguation docs
- CTX covers ad-to-WhatsApp campaign flows; bot conversation logic still lives in **Bot Studio**.

## Reference (from source)
<!-- procedural:v2 -->
# Connecting FB Ad Account to Gupshup Ads Management

**Module**: Ctx

## Overview
Onboarding pre-requisites:

## When to use
_Add the primary scenarios and personas._

## Setup path
- Go to Click to Chat Ads -> Ads Management

## Step-by-step configuration
Onboarding pre-requisites:

- Admin access to Facebook Business Manager
- Access to any page within the FBM
- Access to the ads account through which CTWA ads are to be run if adding multiple ad accounts, please make sure all ad accounts have the same timezone and currency
- if adding multiple ad accounts, please make sure all ad accounts have the same timezone and currency
Steps:

- Go to Click to Chat Ads -> Ads Management
- Click on "Connect Facebook Ad Account"
- Once clicked, you will be redirected to the Facebook in-screen pop-up The first pop-up lists down the Business Portfolio. Select the correct Facebook Business Manager (FBM) which owns the ad account through which CTWA ads will be run. Once selected, click on "Continue" The second screen lists down all the pages the FBM owns. Select any page on this screen and click on "Continue" The third screen shows the list of ad accounts owned by the FBM. Select all the ad accounts that will be used to run CTWA ads on this step and click on "Continue" Click on "Confirm" and keep clicking on "Next" till the Gupshup console screen appears again
- The first pop-up lists down the Business Portfolio. Select the correct Facebook Business Manager (FBM) which owns the ad account through which CTWA ads will be run. Once selected, click on "Continue"
- The second screen lists down all the pages the FBM owns. Select any page on this screen and click on "Continue"
- The third screen shows the list of ad accounts owned by the FBM. Select all the ad accounts that will be used to run CTWA ads on this step and click on "Continue"
- Click on "Confirm" and keep clicking on "Next" till the Gupshup console screen appears again
- Once on the console screen, select all the ad accounts using the check-box
- Click on "Continue" and the onboarding is complete.

## Business hours vs after-hours behavior
_Not applicable / not specified._

## Save/publish behavior
_Not specified._

**Last updated (from source)**: Updated 7 months ago
