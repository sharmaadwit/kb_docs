source_url: https://console-docs.gupshup.io/docs/tiktok-to-whatsapp

<!-- kb-golden:v10 -->
# TikTok to WhatsApp

**Module**: Ctx

## Definition
Please fill out the form and our sales team will reach out to you shortly!

## Procedure
### Exact UI path
Gupshup Console → CTX → TikTok to WhatsApp

### Prerequisites
- Access to **Gupshup Console → CTX → TikTok to WhatsApp** in Gupshup Console.

### Fields to configure
- No explicit fields were identified in the source; use the UI controls shown on this page.

### Steps
1. Open Gupshup Console.
2. Go to **CTX**.
3. Go to **TikTok to WhatsApp**.
4. Connect/onboard Ads Manager to Gupshup console under Click to Chat Ads -> Ad Management.
5. Connect the chatbot to the CTWA enabled ad under Click to Chat Ads -> Ad Management.
6. Click **Save** (or **Save & Deploy**) to apply changes.

### Validation / where to check
- Run a quick test and confirm the expected behavior appears in the target module/UI.

### Troubleshooting
- If something does not work as expected, re-check the exact UI path, required fields, and any save/deploy step.

### Save / publish / deploy behavior
- Click **Save** (or **Save & Deploy**) to apply changes.

### Setup path
- Go to **CTX**.
- Go to **TikTok to WhatsApp**.

## Options / variants
- No explicit UI variants/toggles were identified in the source for this page.

## Field mapping / schemas
- No explicit payload/schema details were identified in the source for this page.

## Field/payload examples
- No explicit payload examples were identified in the source.

## Cross-module workflow docs
- CTX campaign → Bot Studio journey → Goal measurement

## Module disambiguation docs
- CTX covers ad-to-WhatsApp campaign flows; bot conversation logic still lives in **Bot Studio**.

## Reference (from source)
<!-- procedural:v2 -->
# TikTok to WhatsApp

**Module**: Ctx

## Overview
Please fill out the form and our sales team will reach out to you shortly!

## When to use
_Add the primary scenarios and personas._

## Setup path
_In Console: add the navigation path (e.g., `Module → Settings → …`)._

## Step-by-step configuration
Please fill out the form and our sales team will reach out to you shortly!

Pre-Requisites

Access to JB Pro and not JB Lite. TikTok Journeys include code nodes and API nodes in Journey Builder which are only accessible through JB Pro

Essential steps to follow for taking CTWA Ads live:

- Connect/onboard Ads Manager to Gupshup console under Click to Chat Ads -> Ad Management
- Download the TikTok Journey template from sub-section 2 of this document
- Creating the journey in the TikTok template chatbot and follow the instructions in the flow which includes goal nodes and APIs including conversion signals that are sent back to TikTok
- In the starting node, use the trigger "Contains" and add the word "TikTok"
- Convert user journey to ad journey under Bot Studio -> Journeys using Call and Return node
- Connect the chatbot to the CTWA enabled ad under Click to Chat Ads -> Ad Management
# Solution Brief

TikTok's innovative messaging ads offer brands a unique opportunity to engage directly with customers via WhatsApp, enhancing the customer journey and driving real-time conversations. This feature allows users who interact with the ad on TikTok to click on the WhatsApp icon, seamlessly redirecting them to the app where they can initiate a direct conversation with the brand.

By clicking the Click to Action button such as "Send messages" on TikTok Ad, customers are connected to a real-time messaging experience, fostering a more personalized and interactive communication channel. This approach not only helps build stronger customer relationships but also encourages immediate engagement, which can lead to higher conversion rates and improved customer satisfaction.

To fully optimize the potential of TikTok messaging ads, brands are advised to integrate with platforms like Gupshup. Gupshup offers robust tools and automation capabilities that enable brands to fine-tune their messaging strategies. Through this integration, businesses can streamline customer interactions, manage high volumes of messages efficiently, and personalize communication to enhance the user experience.

With the combination of TikTok's engaging ad platform and Gupshup’s automation capabilities, brands can create a seamless, data-driven journey that delivers better results and improved ROI. Whether it's providing instant support, answering queries, or facilitating purchases, the integration between TikTok and WhatsApp opens up a new realm of possibilities for businesses to connect with their audience on a deeper level.

Please fill out the form and our sales team will reach out to you

## Business hours vs after-hours behavior
_Not applicable / not specified._

## Save/publish behavior
_Not specified._

**Last updated (from source)**: Updated about 1 month ago
