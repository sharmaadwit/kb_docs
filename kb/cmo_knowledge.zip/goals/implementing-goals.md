source_url: https://console-docs.gupshup.io/docs/implementing-goals

<!-- kb-golden:v10 -->
# Implementing Goals

**Module**: Goals

## Definition
Please refer to your journey and create Milestones and Trackers accordingly. You CANNOT implement Goal nodes without creating them.

## Journey Builder setup
- Create the **goal**, **milestones**, and **trackers** in **Gupshup Console → Goals** first.
- Open **Bot Studio → Journey Builder**, then add a **Goal Node** on the canvas where the milestone should fire.
- Configure the Goal Node to select the goal, milestone, and tracker; users traversing the journey will then count toward **Goal Analytics**.

## Procedure
### Exact UI path
Gupshup Console → Goals → Implementing Goals

### Prerequisites
- A goal configured in the Goals module or a journey that references it.

### Fields to configure
- No explicit fields were identified in the source; use the UI controls shown on this page.

### Steps
1. Open Gupshup Console.
2. Go to **Goals**.
3. Go to **Implementing Goals**.
4. Click **Save** (or **Save & Deploy**) to apply changes.

### Validation / where to check
- Run a test event/journey and confirm the expected analytics or goal data appears in the UI.

### Troubleshooting
- Please refer to your journey and create Milestones and Trackers accordingly. You CANNOT implement Goal nodes without creating them.

### Save / publish / deploy behavior
- Click **Save** (or **Save & Deploy**) to apply changes.

### Setup path
- Go to **Goals**.
- Go to **Implementing Goals**.

## Options / variants
- No explicit UI variants/toggles were identified in the source for this page.

## Field mapping / schemas
- No explicit payload/schema details were identified in the source for this page.

## Field/payload examples
- No explicit payload examples were identified in the source.

## Cross-module workflow docs
- Identify the upstream module where this is configured and the downstream module where the outcome is verified.

## Module disambiguation docs
- Distinguish this page from adjacent modules/settings before troubleshooting elsewhere.

## Reference (from source)
<!-- procedural:v2 -->
# Implementing Goals

**Module**: Goals

## Overview
Please refer to your journey and create Milestones and Trackers accordingly. You CANNOT implement Goal nodes without creating them.

## When to use
_Add the primary scenarios and personas._

## Setup path
_In Console: add the navigation path (e.g., `Module → Settings → …`)._

## Step-by-step configuration
### You need to create Goals before you can implement them in your journeys.

Please refer to your journey and create Milestones and Trackers accordingly. You CANNOT implement Goal nodes without creating them.

You can implement Goals within your journeys by adding Goal Nodes.

## Adding Goal Nodes in Journeys

- You can add a Goal Node at the point in your Journey where the user has achieved a Milestone.
### Milestones are sequential in nature. Their sequence is set as per creation, NOT implementation in journeys.

For example, if a Goal has been created with three Milestones in the sequence M1 followed by M2 followed by M3, their sequence remains the same even if M2 and M3 is implemented in a Goal node before M1.

### If a Milestone is skipped and a Milestone after it in the sequence of creation is achieved, the Tracker Values for that milestone are automatically filled with the respective Default Values against the user’s customer ID.

For example, if a user achieves the third Milestone without achieving the first and second Milestones, the respective Default Values are set as Tracker Values entered by that user in the first and second Milestones.

- Then select the name of Goal and the name of the Milestone being achieved from the respective dropdowns.
- The Trackers associated with the selected Milestone will be populated in the Goal node.
- Finally, assign a Tracker Value for each Tracker. You can enter a fixed value or a variable.
Updated 10 months ago

- Goal Analytics

## Business hours vs after-hours behavior
_Not applicable / not specified._

## Save/publish behavior
_Not specified._
