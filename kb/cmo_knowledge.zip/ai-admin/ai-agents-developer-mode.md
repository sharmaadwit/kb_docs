source_url: https://console-docs.gupshup.io/docs/introducing-ai-agents

<!-- kb-golden:v10 -->
# AI Agents (Developer Mode)

**Module**: Ai Admin

## Definition
Gupshup's AI Agents represent the next evolution in enterprise communication—sophisticated digital assistants engineered to deliver seamless, contextual, and multi-turn conversations across WhatsApp and Web Channels

## Procedure
### Exact UI path
Gupshup Console → Ai Admin → AI Agents (Developer Mode)

### Prerequisites
- Access to **Gupshup Console → Ai Admin → AI Agents (Developer Mode)** in Gupshup Console.

### Fields to configure
- No explicit fields were identified in the source; use the UI controls shown on this page.

### Steps
1. Open Gupshup Console.
2. Go to **Ai Admin**.
3. Go to **AI Agents (Developer Mode)**.
4. Click **Save** (or **Save & Deploy**) to apply changes.

### Validation / where to check
- Optimize & Deploy: Fine-tune settings, validate performance, and launch

### Troubleshooting
- If something does not work as expected, re-check the exact UI path, required fields, and any save/deploy step.

### Save / publish / deploy behavior
- Click **Save** (or **Save & Deploy**) to apply changes.

### Setup path
- Go to **Ai Admin**.
- Go to **AI Agents (Developer Mode)**.

## Options / variants
- No explicit UI variants/toggles were identified in the source for this page.

## Field mapping / schemas
- No explicit payload/schema details were identified in the source for this page.

## Field/payload examples
- No explicit payload examples were identified in the source.

## Cross-module workflow docs
- Identify the upstream module where this is configured and the downstream module where the outcome is verified.

## Module disambiguation docs
- Distinguish this page from adjacent modules/settings before troubleshooting elsewhere.

## Reference (from source)
<!-- procedural:v2 -->
# AI Agents (Developer Mode)

**Module**: Ai Admin

## Overview
Gupshup's AI Agents represent the next evolution in enterprise communication—sophisticated digital assistants engineered to deliver seamless, contextual, and multi-turn conversations across WhatsApp and Web Channels

## When to use
_Add the primary scenarios and personas._

## Setup path
_In Console: add the navigation path (e.g., `Module → Settings → …`)._

## Step-by-step configuration
### Note: AI Agent is available in developer mode through our Gupshup’s internal Bot Solutions Team. To access the latest AI Agent modules in Bot Studio please contact Gupshup support or your respective Sales representative.

# Elevating Customer Experience: The Gupshup Agentic Framework Advantage

Gupshup's AI Agents represent the next evolution in enterprise communication—sophisticated digital assistants engineered to deliver seamless, contextual, and multi-turn conversations across WhatsApp and Web Channels

These advanced Agents go beyond traditional rule-based bots by masterfully orchestrating our four core components:

- Distinctive Agent Personalities that authentically represent your brand
- Specialized Skills for handling complex conversation flows
- Integrated Tools that connect with your enterprise systems in real-time
- Optimized Settings ensuring peak performance across all interactions
By leveraging powerful Large Language Models within our Agentic Framework, enterprises can elevate critical customer experience conversations like Lead Generation, Product Discovery, Collections, and Order Management—all while maintaining the personalized, natural, responsive interaction your customers expect.

Transform how your business engages with customers through AI agents that combine structured knowledge with contextual understanding, creating meaningful connections across every digital touchpoint.

Four Powerful Components Working in Harmony

- Agent Personality: Create a distinctive Agentic personality with customizable tone, behavior, and greeting patterns that reflect your brand identity.
- Skills: Deploy task-specific capabilities through specialized prompts, enabling your agent to perform exactly as your business requires and meet the engagement expectation
- Tools: Seamlessly connect with external systems and real-time data sources to deliver accurate, contextual responses.
- Settings: Fine-tune performance with granular controls for LLM model parameters and response configurations at both global and skill-specific levels.
Launch Your AI Agent in 5 Streamlined Steps

- Create & Train: Establish a new Workspace tailored to your specific needs
- Define Personality: Craft the perfect digital representative for your brand
- Design Skills: Select and customize capabilities for your use cases
- Integrate Tools: Choose from our pre-built library or configure custom connections
- Optimize & Deploy: Fine-tune settings, validate performance, and launch
Updated 10 months ago

- Agent Personality (Developer Mode)

## Business hours vs after-hours behavior
_Not applicable / not specified._

## Save/publish behavior
Key notes found in source:

- - Skills: Deploy task-specific capabilities through specialized prompts, enabling your agent to perform exactly as your business requires and meet the engagement expectation
- Launch Your AI Agent in 5 Streamlined Steps
- - Optimize & Deploy: Fine-tune settings, validate performance, and launch
