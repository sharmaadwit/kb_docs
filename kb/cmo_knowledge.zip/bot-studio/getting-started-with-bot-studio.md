source_url: https://console-docs.gupshup.io/docs/create-a-new-journey

<!-- kb-golden:v10 -->
# Getting Started with Bot Studio

**Module**: Bot Studio

## Definition
Journeys Landing Page

## Procedure
### Exact UI path
Gupshup Console → Bot Studio → Getting Started with Bot Studio

### Prerequisites
- Preview - Users have the option to preview a template to ensure it fits their requirements before using it.

### Fields to configure
- Message content

### Steps
1. Open Gupshup Console.
2. Go to **Bot Studio**.
3. Go to **Getting Started with Bot Studio**.
4. Test Bot: Preview your journey (Web channel only; some WhatsApp-exclusive features may not work).
5. Click the ‘Create Journey’ button on the landing page.
6. Click ‘Create Journey’.
7. Toggle Interactivity.
8. Save: Use this button to save progress frequently.
9. Save & Deploy: Makes the journey live for production use.
10. Test Bot: Lets you test the journey on the Web widget. Use it to validate message flows and payloads.

### Validation / where to check
- Database (Dev Mode), Test Bot & Create Journey
- Test Bot: Preview your journey (Web channel only; some WhatsApp-exclusive features may not work)
- ### Test Bot & Saving options
- Test Bot: Lets you test the journey on the Web widget. Use it to validate message flows and payloads.
- ### Note: Test Bot becomes available only after you Save & Deploy your journey.
- NOTE: You can use the Test Bot only after Saving and Deploying the journey

### Troubleshooting
- If behavior is unchanged, confirm you updated the correct node and used **Save & Deploy** for live channels.
- If the wrong branch/path runs, re-check conditions, connected nodes, and fallback connectors.

### Save / publish / deploy behavior
- Click **Save** (or **Save & Deploy**) to apply changes.

### Setup path
- Go to **Bot Studio**.
- Go to **Getting Started with Bot Studio**.

## Options / variants
- Canvas Tools: Zoom in/out Fit View Toggle Interactivity Organize blocks Align nodes horizontally/vertically
- Toggle Interactivity
- ### Analytics Toggle
- Analytics Toggle

## Field mapping / schemas
- No explicit payload/schema details were identified in the source for this page.

## Field/payload examples
- No explicit payload examples were identified in the source.

## Cross-module workflow docs
- Bot Studio journey → Channel go-live (WhatsApp/Instagram/Web)
- Bot Studio journey → Observability via Webhooks

## Module disambiguation docs
- **Save** stores changes; **Save & Deploy** publishes to live channels.
- Node configuration happens in **Bot Studio**; delivery/engagement metrics are typically in **Analytics/Insights**.

## Reference (from source)
<!-- procedural:v2 -->
# Getting Started with Bot Studio

**Module**: Bot Studio

## Overview
Journeys Landing Page

## When to use
_Add the primary scenarios and personas._

## Setup path
_In Console: add the navigation path (e.g., `Module → Settings → …`)._

## Step-by-step configuration
## The Landing Page (Journeys)

Journeys Landing Page

The Journeys Landing Page is your central hub to create, manage, and track conversational journeys built in Bot Studio. From here, you can access tools for building from scratch or using templates, importing/exporting journeys, and testing bots in real-time.

### Key Sections on the Landing Page

- Journey Type & Templates Dropdown Select from different journey types: User Journeys Ad Journeys Campaign Journeys The templates panel is accessible here too (see Using Templates).
Journey Type & Templates Dropdown Select from different journey types:

- User Journeys
- Ad Journeys
- Campaign Journeys The templates panel is accessible here too (see Using Templates).
- Search Bar Quickly find your journeys by searching their names.
Search Bar Quickly find your journeys by searching their names.

- Saved & Deployed Journeys View journeys that are saved, deployed, or in progress—ordered by most recent save time.
Saved & Deployed Journeys View journeys that are saved, deployed, or in progress—ordered by most recent save time.

- Import, Export & Bot Settings Import/export journey JSONs Access additional configurations via Bot Settings
Import, Export & Bot Settings

- Import/export journey JSONs
- Access additional configurations via Bot Settings
- Database (Dev Mode), Test Bot & Create Journey Database: Beta feature, available for Gupshup internal devs only Test Bot: Preview your journey (Web channel only; some WhatsApp-exclusive features may not work) Create Journey: Launch the builder to start crafting a new journey
Database (Dev Mode), Test Bot & Create Journey

- Database: Beta feature, available for Gupshup internal devs only
- Test Bot: Preview your journey (Web channel only; some WhatsApp-exclusive features may not work)
- Create Journey: Launch the builder to start crafting a new journey
## Taking the Product Tour

To start with an onboarding experience:

- Click the ‘Create Journey’ button on the landing page.
- In the pop-up, select “Product Tour” to begin the guided walk-through.
Step 1

Step 2

## Create a New Journey from Scratch

To build a journey manually:

- Click ‘Create Journey’
- In the dialogue, choose “Start from Scratch”
- You will be redirected to the Journey Builder Canvas with a blank journey ready to edit
Step 1

Step 2

And the journey builder will open with a new journey created.

## Journey Builder (New Journey)

The journey builder tool has few major components which are shown below. We'll discuss about them one by one:

### Side Options

### 🔧 Side Panel Tools

- Actions & Prompts: Includes all message, action, and prompt nodes
- Manage Variables: Create & edit local/system/global variables
- Manage APIs: Add or import external APIs
- Manage Settings: Configure journey-level settings
### 🗺️ Mini-Map & Tools

- Mini-Map: Visual indicator of your current view in the journey layout
- Canvas Tools: Zoom in/out Fit View Toggle Interactivity Organize blocks Align nodes horizontally/vertically
- Zoom in/out
- Fit View
- Toggle Interactivity
- Organize blocks
- Align nodes horizontally/vertically
### Starting Node

Each journey begins with a Starting Node, which acts as the trigger point. There are 4 possible types of triggers:

- No Event
- User Input
- AI Trigger (Intent-based)
- Custom Event / Callback URL
🔗 Learn more: Starting Node Docs

### Test Bot & Saving options

## Saving and Testing Journeys

- Save: Use this button to save progress frequently.
- Save & Deploy: Makes the journey live for production use.
- Test Bot: Lets you test the journey on the Web widget. Use it to validate message flows and payloads.
### Note: Test Bot becomes available only after you Save & Deploy your journey.

NOTE: You can use the Test Bot only after Saving and Deploying the journey

### Analytics Toggle

Analytics Toggle

Turn on the 'Analytics' toggle to get the inside stats of the journey flow. Stats are given for each node and their connecting lines.

## Using the Templates

Step 1 - Templates Section

The Templates section provides users with access to pre-built journeys designed for generic scenarios. This allows users to quickly find a template that closely matches their specific use case and customize it to meet their needs.

Step 2 - Templates Categories

On the left side, the templates are arranged in categories. Choose the category you need and you'll see the templates of that category.

Users have two option on a template card:

Preview - Users have the option to preview a template to ensure it fits their requirements before using it.

Journey Type - From the drop down, you can select the journey type and start using the template. It offers two options - User Journey & Ad Journey

Preview or Use Template here

## Business hours vs after-hours behavior
_Not applicable / not specified._

## Save/publish behavior
Key notes found in source:

- - Saved & Deployed Journeys View journeys that are saved, deployed, or in progress—ordered by most recent save time.
- Saved & Deployed Journeys View journeys that are saved, deployed, or in progress—ordered by most recent save time.
- - Create Journey: Launch the builder to start crafting a new journey
- - Save: Use this button to save progress frequently.
- - Save & Deploy: Makes the journey live for production use.
- ### Note: Test Bot becomes available only after you Save & Deploy your journey.

**Last updated (from source)**: Updated 10 months ago
