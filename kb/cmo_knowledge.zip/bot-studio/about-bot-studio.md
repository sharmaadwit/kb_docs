source_url: https://console-docs.gupshup.io/docs/about-bot-studio

<!-- kb-golden:v10 -->
# About Bot Studio

**Module**: Bot Studio

## Definition
Bot Studio is Gupshup’s visual, no-code/low-code platform that empowers users to design, build, and deploy intelligent conversational journeys across messaging channels like WhatsApp, Web, and Instagram.

## Procedure
### Exact UI path
Gupshup Console → Bot Studio → About Bot Studio

### Prerequisites
- Access to the relevant bot/project in Gupshup Console.
- A journey/app where you can test the configuration.

### Fields to configure
- No explicit fields were identified in the source; use the UI controls shown on this page.

### Steps
1. Open Gupshup Console.
2. Go to **Bot Studio**.
3. Go to **About Bot Studio**.
4. Click **Save** (or **Save & Deploy**) to apply changes.

### Validation / where to check
- Run the flow in **Test your Bot** and confirm the expected node/path executes.
- If the change must affect live traffic, use **Save & Deploy** and verify on the target channel.

### Troubleshooting
- If behavior is unchanged, confirm you updated the correct node and used **Save & Deploy** for live channels.
- If the wrong branch/path runs, re-check conditions, connected nodes, and fallback connectors.

### Save / publish / deploy behavior
- Click **Save** (or **Save & Deploy**) to apply changes.

### Setup path
- Go to **Bot Studio**.
- Go to **About Bot Studio**.

## Options / variants
- Developer Mode toggle → Removed

## Field mapping / schemas
- No explicit payload/schema details were identified in the source for this page.

## Field/payload examples
- No explicit payload examples were identified in the source.

## Cross-module workflow docs
- Bot Studio journey → Channel go-live (WhatsApp/Instagram/Web)
- Bot Studio journey → Observability via Webhooks

## Module disambiguation docs
- **Save** stores changes; **Save & Deploy** publishes to live channels.
- Node configuration happens in **Bot Studio**; delivery/engagement metrics are typically in **Analytics/Insights**.

## Reference (from source)
<!-- procedural:v2 -->
# About Bot Studio

**Module**: Bot Studio

## Overview
Bot Studio is Gupshup’s visual, no-code/low-code platform that empowers users to design, build, and deploy intelligent conversational journeys across messaging channels like WhatsApp, Web, and Instagram.

## When to use
_Add the primary scenarios and personas._

## Setup path
_In Console: add the navigation path (e.g., `Module → Settings → …`)._

## Step-by-step configuration
## What is Bot Studio

Bot Studio is Gupshup’s visual, no-code/low-code platform that empowers users to design, build, and deploy intelligent conversational journeys across messaging channels like WhatsApp, Web, and Instagram.

With an intuitive drag-and-drop canvas, users can craft dynamic bots using modular nodes for messages, prompts, API calls, and conditional logic—without writing a single line of code.

Bot Studio supports:

- Self-serve (DIY) use cases
- Advanced enterprise solutions via internal developer tooling
It is versatile enough for:

- Lead generation
- Customer support
- Campaign automation
- Transactional flows
Whether you're a business user or a developer, Bot Studio provides the tools to deliver scalable, personalized, and engaging customer experiences.

## Bot Studio Versions

Bot Studio is available in two versions depending on the user’s needs and offering type:

### 1. Journey Builder (V2)

Journey Builder V2 is Gupshup’s intuitive, no-code/low-code platform for business teams and GTM users.

Key Features:

- Drag-and-drop builder
- Message, prompt, API, and logic nodes
- Expression Library for advanced data ops
- JSON Handler for parsing API responses
- Rapid setup and deployment
Best suited for:

- Lead capture
- Appointment booking
- Support automation
- Teams looking for self-serve, go-live-fast capabilities
### 2. Journey Builder Pro

Journey Builder Pro is the developer-grade version of JB V2, exclusively for Gupshup’s internal Bot Solutions team.

Includes everything in JB V2, plus:

- Access to Function Node via the Solutions Platform
- Supports custom logic, complex integrations, and real-time data handling
Best suited for:

- Enterprise use cases
- Transactional workflows
- Fully managed projects with internal developer support
### JB Pro is not available for self-serve users.

## ⚠️ Note on Deprecated Nodes and Features

### Starting with Console 16.0, Gupshup has deprecated or replaced several legacy and dev-only nodes in Bot Studio to improve platform stability, performance, and user experience.

### ❌ Deprecated / Replaced Nodes:

- Code Node → Replaced by Function Node (JB Pro only)
- Database Node (RQ Lite) → Deprecated, SQL-based access available via JB Pro
- Send Message Node (generic) → Replaced by dedicated message-type nodes like: Audio Sticker Send Location Address
- Audio
- Sticker
- Send Location
- Address
### ⚙️ Other Changes:

- Clear Context Node → Available on JB Pro
- Dynamic Image URL Node → Available on JB Pro
- Developer Mode toggle → Removed
These changes ensure a simplified, robust experience for JB V2 users, while giving JB Pro developers controlled access to powerful tooling via the Solutions Platform.

## Business hours vs after-hours behavior
_Not applicable / not specified._

## Save/publish behavior
_Not specified._

**Last updated (from source)**: Updated 10 months ago
