source_url: https://console-docs.gupshup.io/docs/others-agent-status







<!-- agent-assist-golden:v11 -->
# Others: Agent Status

**Module**: Agent Assist

## What this feature does
Agent Status Agent Status is a feature in Agent Assist that allows agents to communicate their current state to their teams. There are three main categories of Agent Status: Available, Busy, and Unavailable. Available: When an agent sets their status to "Available", it means they are ready to receive and handle new chats. They are actively monitoring the dashboard and can respond to customer inquiries in real time. Busy: When an agent sets their status to "Busy", it means they are currently handling a chat and cannot take on any new chats. This status is particularly useful when an agent is handling a complex issue and needs to focus on a single chat until it is resolved. Unavailable: When an agent sets their status to "Unavailable", it means they are temporarily not available to handle chats. This could be due to taking a break, being in a meeting, or dealing with an emergency.

## Exact UI path
Gupshup Console → Agent Assist → Settings → Others

## Prerequisites
- Access to the relevant Agent Assist module/page.

## Setup path
- Gupshup Console → **Agent Assist** → **Settings** → **Others** → **Agent Status**

## Fields to configure
- No explicit fields were identified in the source; use the controls shown on this page.

## Steps
1. Open Agent Assist.
2. Open **Settings** → **Others** → **Agent Status**.
3. Click **Save** to apply changes.

## Validation / where to check
- Run a quick test and confirm the expected behavior in Agent Assist.

## Save / publish / deploy behavior
- Click **Save** (or **Save & Deploy** if available) to apply changes.

## Troubleshooting
- If something does not work as expected, re-check the exact path, required fields, and save step.

## Options / variants
- No explicit UI variants/toggles were identified in the source for this page.

## Cross-module workflow docs
- Identify the upstream Agent Assist setting and the downstream chat/reporting behavior it affects.

## Module disambiguation docs
- Distinguish this page from adjacent Agent Assist settings before troubleshooting elsewhere.

## Reference (from source)
### Overview
Agent Status Agent Status is a feature in Agent Assist that allows agents to communicate their current state to their teams. There are three main categories of Agent Status: Available, Busy, and Unavailable. Available: When an agent sets their status to "Available", it means they are ready to receive and handle new chats. They are actively monitoring the dashboard and can respond to customer inquiries in real time. Busy: When an agent sets their status to "Busy", it means they are currently handling a chat and cannot take on any new chats. This status is particularly useful when an agent is handling a complex issue and needs to focus on a single chat until it is resolved. Unavailable: When an agent sets their status to "Unavailable", it means they are temporarily not available to handle chats. This could be due to taking a break, being in a meeting, or dealing with an emergency.

### When to use
_Add the primary scenarios and personas._

### Details
Agent Status Agent Status is a feature in Agent Assist that allows agents to communicate their current state to their teams. There are three main categories of Agent Status: Available, Busy, and Unavailable. Available: When an agent sets their status to "Available", it means they are ready to receive and handle new chats. They are actively monitoring the dashboard and can respond to customer inquiries in real time. Busy: When an agent sets their status to "Busy", it means they are currently handling a chat and cannot take on any new chats. This status is particularly useful when an agent is handling a complex issue and needs to focus on a single chat until it is resolved. Unavailable: When an agent sets their status to "Unavailable", it means they are temporarily not available to handle chats. This could be due to taking a break, being in a meeting, or dealing with an emergency.

In addition to these three main categories, Agent Assist also offers a few other status options that agents can choose from, including "On a Call" and "In a Meeting". These statuses allow agents to communicate their availability to handle chats with their team and customers more effectively. Overall, Agent Status is a useful tool for agents to manage their workload, communicate their availability, and provide better customer service. By setting the appropriate status at any given time, agents can ensure that they are handling chats efficiently and effectively, which can lead to higher customer satisfaction and better team collaboration.
