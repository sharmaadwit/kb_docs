source_url: https://console-docs.gupshup.io/docs/ai-management-alpha







<!-- agent-assist-golden:v11 -->
# AI Management (Alpha)

**Module**: Agent Assist

## What this feature does
Definition: Text Generation in AI Management encompasses a set of features that assist agents in enhancing productivity and providing quicker and improved customer support. These features include Summary, Rephrase, and Expand.

## Exact UI path
Gupshup Console → Agent Assist → Settings → AI Management → Text Generation

## Prerequisites
- Access to the relevant Agent Assist module/page.

## Setup path
- Gupshup Console → **Agent Assist** → **Settings** → **AI Management** → **Text Generation**

## Fields to configure
- No explicit fields were identified in the source; use the controls shown on this page.

## Steps
1. Open Agent Assist.
2. Go to **Settings** → **AI Management** → **Text Generation** to enable Summary / Rephrase / Expand per agent.

## Validation / where to check
- Run a quick test and confirm the expected behavior in Agent Assist.

## Save / publish / deploy behavior
- No save/publish step is required for this page unless explicitly stated in the UI.

## Troubleshooting
- If something does not work as expected, re-check the exact path, required fields, and save step.

## Options / variants
- No explicit UI variants/toggles were identified in the source for this page.

## Cross-module workflow docs
- Identify the upstream Agent Assist setting and the downstream chat/reporting behavior it affects.

## Module disambiguation docs
- Distinguish this page from adjacent Agent Assist settings before troubleshooting elsewhere.

## Reference (from source)
### Overview
Definition: Text Generation in AI Management encompasses a set of features that assist agents in enhancing productivity and providing quicker and improved customer support. These features include Summary, Rephrase, and Expand.

### When to use
- These AI features play a vital role in streamlining agent activities, summarizing conversations, improving text quality, and expanding sentences to provide comprehensive responses.
- Summary simplifies conversation review, making it easier to understand and evaluate the interaction flow between customers, bots, and agents.
- Rephrase improves the clarity and quality of text, ensuring that messages are conveyed accurately and effectively.
- Expand is helpful when a more comprehensive answer or explanation is required, ensuring that customers receive detailed and informative responses.

### Details
Introduction

Definition: Text Generation in AI Management encompasses a set of features that assist agents in enhancing productivity and providing quicker and improved customer support. These features include Summary, Rephrase, and Expand.

Uses: These AI features play a vital role in streamlining agent activities, summarizing conversations, improving text quality, and expanding sentences to provide comprehensive responses.

Summary

Definition: The Summary feature allows users to view an entire conversation summarized into segments based on Customer Purpose, Bot Response, and Agent Response.

Uses: Summary simplifies conversation review, making it easier to understand and evaluate the interaction flow between customers, bots, and agents.

Rephrase

Definition: The Rephrase feature enhances content by making it more meaningful, effective, and free from errors.

Uses: Rephrase improves the clarity and quality of text, ensuring that messages are conveyed accurately and effectively.

Expand

Definition: The Expand feature takes a sentence and transforms it into a longer version, providing a more detailed response.

Uses: Expand is helpful when a more comprehensive answer or explanation is required, ensuring that customers receive detailed and informative responses.

Activation and Configuration

Definition: These features are available in alpha mode and can be enabled upon request. After activation, they can be configured based on specific requirements.

Activation Steps:

Step 1: Navigate to "Settings" > "AI Management" > "Text Generation."

Step 2: Select the agents for whom you want to enable these features.

Step 3: Choose the specific feature(s) to enable and set the daily usage limits for each of them.

Text Generation AI features are powerful tools for enhancing agent efficiency and providing superior customer support. By enabling and configuring these features, users can experience improved productivity and faster, more effective customer interactions.
